"""
App-scoped constants.
"""
OWM_API_KEY = "687dab72577e4a4fef7efc05ab8e8b63"
OWM_API_CLIENT_TIMEOUT = 5
